import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { insertRecordingSchema, updateRecordingSchema } from "@shared/schema";
import { z } from "zod";

const upload = multer({ dest: "uploads/" });

const ASSEMBLYAI_API_KEY = process.env.ASSEMBLYAI_API_KEY || "937dcd75a8424674b66b9f4923910a65";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get recent recordings
  app.get("/api/recordings", async (req, res) => {
    try {
      const recordings = await storage.getRecentRecordings();
      res.json(recordings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recordings" });
    }
  });

  // Get specific recording
  app.get("/api/recordings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recording = await storage.getRecording(id);
      
      if (!recording) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json(recording);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recording" });
    }
  });

  // Upload and transcribe audio
  app.post("/api/transcribe", upload.single("audio"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No audio file provided" });
      }

      const { type } = req.body;
      
      if (!type || !["lecture", "meeting"].includes(type)) {
        return res.status(400).json({ error: "Invalid recording type" });
      }

      // Calculate audio duration
      let estimatedDuration = 0;
      try {
        // Estimate duration based on file size (more accurate calculation)
        const fileSizeMB = req.file.size / (1024 * 1024);
        // For typical audio compression: ~1MB per minute for speech
        // For longer recordings, compression is often better
        if (fileSizeMB > 10) {
          // For large files, assume better compression ratio
          estimatedDuration = Math.round(fileSizeMB * 80); // ~80 seconds per MB
        } else {
          // For smaller files, standard calculation
          estimatedDuration = Math.round(fileSizeMB * 60); // ~60 seconds per MB
        }
      } catch (error) {
        console.log("Could not estimate duration:", error);
      }

      // Create initial recording record
      const recording = await storage.createRecording({
        title: `${type === "lecture" ? "강의" : "회의"} 녹음 - ${new Date().toLocaleDateString("ko-KR")}`,
        type,
        duration: estimatedDuration,
        transcription: null,
        summary: null,
        filePath: req.file.path,
        assemblyaiId: null,
        status: "processing",
      });

      // Start transcription process (non-blocking)
      processTranscription(recording.id, req.file.path, type);

      res.json({ recordingId: recording.id, status: "processing" });
    } catch (error) {
      console.error("Transcription error:", error);
      res.status(500).json({ error: "Failed to start transcription" });
    }
  });

  // Get individual recording
  app.get("/api/recordings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recording = await storage.getRecording(id);
      
      if (!recording) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json(recording);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recording" });
    }
  });

  // Get transcription status
  app.get("/api/recordings/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recording = await storage.getRecording(id);
      
      if (!recording) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json({ 
        status: recording.status,
        transcription: recording.transcription,
        summary: recording.summary 
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch status" });
    }
  });

  // Delete recording
  app.delete("/api/recordings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteRecording(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete recording" });
    }
  });

  // Save recording (mark as saved)
  app.post("/api/recordings/:id/save", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updated = await storage.updateRecording(id, { isSaved: true });
      
      if (!updated) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to save recording" });
    }
  });

  // Update speaker names
  app.patch("/api/recordings/:id/speakers", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { speakerNames } = req.body;
      
      const recording = await storage.updateRecording(id, { 
        speakerNames: JSON.stringify(speakerNames) 
      });
      
      if (!recording) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json({ success: true, recording });
    } catch (error) {
      res.status(500).json({ error: "Failed to update speaker names" });
    }
  });

  // Update recording title
  app.patch("/api/recordings/:id/title", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { title } = req.body;
      
      const recording = await storage.updateRecording(id, { title });
      
      if (!recording) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json({ success: true, recording });
    } catch (error) {
      res.status(500).json({ error: "Failed to update title" });
    }
  });

  // Update recording content (transcription and summary)
  app.patch("/api/recordings/:id/content", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { transcription } = req.body;
      
      if (!transcription) {
        return res.status(400).json({ error: "Transcription content required" });
      }

      const updated = await storage.updateRecording(id, { transcription });
      
      if (!updated) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json({ success: true, recording: updated });
    } catch (error) {
      console.error("Content update error:", error);
      res.status(500).json({ error: "Failed to update content" });
    }
  });

  // Update recording title
  app.patch("/api/recordings/:id/title", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { title } = req.body;
      
      if (!title || title.trim().length === 0) {
        return res.status(400).json({ error: "Title is required" });
      }

      const updated = await storage.updateRecording(id, { title: title.trim() });
      
      if (!updated) {
        return res.status(404).json({ error: "Recording not found" });
      }
      
      res.json({ success: true, recording: updated });
    } catch (error) {
      console.error("Title update error:", error);
      res.status(500).json({ error: "Failed to update title" });
    }
  });

  // Regenerate speaker analysis for existing recording
  app.post("/api/recordings/:id/regenerate-analysis", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recording = await storage.getRecording(id);
      
      if (!recording || !recording.speakers) {
        return res.status(404).json({ error: "Recording or speaker data not found" });
      }

      const speakers = JSON.parse(recording.speakers);
      const newSpeakerSummary = JSON.stringify(generateSpeakerSummary(speakers, recording.type));
      
      const updated = await storage.updateRecording(id, { 
        speakerSummary: newSpeakerSummary 
      });
      
      res.json({ 
        success: true, 
        recording: updated,
        message: "화자별 분석이 새로운 알고리즘으로 재생성되었습니다."
      });
    } catch (error) {
      console.error("Analysis regeneration error:", error);
      res.status(500).json({ error: "Failed to regenerate analysis" });
    }
  });

  // AI-powered transcription refinement
  app.post("/api/recordings/:id/refine", async (req, res) => {
    try {
      const { transcription } = req.body;
      
      if (!process.env.ANTHROPIC_API_KEY) {
        return res.status(500).json({ error: "Anthropic API key not configured" });
      }

      const Anthropic = require('@anthropic-ai/sdk');
      const anthropic = new Anthropic({
        apiKey: process.env.ANTHROPIC_API_KEY,
      });

      const prompt = `다음 음성 전사 텍스트를 정제해주세요. 맞춤법, 문법, 구두점을 수정하고 자연스럽게 읽히도록 개선하되, 원본의 의미와 내용은 변경하지 마세요.

원본 전사:
${transcription}

정제된 텍스트:`;

      const response = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', // the newest Anthropic model is "claude-sonnet-4-20250514" which was released May 14, 2025. Use this by default unless user has already selected claude-3-7-sonnet-20250219
        max_tokens: 4000,
        messages: [{ role: 'user', content: prompt }],
      });

      const refinedTranscription = response.content[0].text;
      
      res.json({ 
        success: true, 
        refinedTranscription,
        original: transcription 
      });
    } catch (error) {
      console.error("AI refinement error:", error);
      res.status(500).json({ error: "Failed to refine transcription" });
    }
  });

  // Download project archive
  app.get("/download", async (req, res) => {
    try {
      const filePath = "./voice-recording-project.tar.gz";
      
      // Check if file exists
      const fs = await import("fs");
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: "File not found" });
      }
      
      res.download(filePath, "voice-recording-project.tar.gz", (err) => {
        if (err) {
          console.error("Download error:", err);
          if (!res.headersSent) {
            res.status(500).json({ error: "Download failed" });
          }
        }
      });
    } catch (error) {
      console.error("Download route error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function processTranscription(recordingId: number, filePath: string, type: string) {
  const startTime = Date.now();
  console.log(`Starting transcription processing for recording ${recordingId}, type: ${type}`);
  
  try {
    // Get file stats for optimization
    const fs = await import("fs");
    const path = await import("path");
    const fileStats = fs.statSync(filePath);
    const fileSizeMB = fileStats.size / (1024 * 1024);
    
    console.log(`File size: ${fileSizeMB.toFixed(2)}MB`);
    
    // Read and upload file to AssemblyAI with progress tracking
    const fileBuffer = fs.readFileSync(filePath);
    
    console.log(`Uploading file to AssemblyAI...`);
    const uploadResponse = await fetch("https://api.assemblyai.com/v2/upload", {
      method: "POST",
      headers: {
        "authorization": ASSEMBLYAI_API_KEY,
        "content-type": "application/octet-stream",
      },
      body: fileBuffer,
    });

    if (!uploadResponse.ok) {
      const errorData = await uploadResponse.text();
      console.error("AssemblyAI Upload Error:", uploadResponse.status, errorData);
      throw new Error(`Failed to upload to AssemblyAI: ${uploadResponse.status} - ${errorData}`);
    }

    const { upload_url } = await uploadResponse.json();
    const uploadTime = Date.now() - startTime;
    console.log(`File uploaded successfully in ${uploadTime}ms`);

    // Request transcription with optimized settings
    console.log(`Requesting transcription from AssemblyAI...`);
    const transcriptionResponse = await fetch("https://api.assemblyai.com/v2/transcript", {
      method: "POST",
      headers: {
        "authorization": ASSEMBLYAI_API_KEY,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        audio_url: upload_url,
        speaker_labels: true,
        speakers_expected: null, // 자동으로 화자 수 감지
        language_code: "ko",
        punctuate: true,
        format_text: true,
        disfluencies: false,
        // Speed optimization settings for long recordings
        speed_boost: fileSizeMB > 50, // Enable speed boost for files > 50MB
        boost_param: fileSizeMB > 100 ? "high" : "default", // High boost for very large files
        webhook_url: null, // Use polling for reliability
        // auto_chapters는 한국어에서 지원되지 않음
      }),
    });

    if (!transcriptionResponse.ok) {
      const errorData = await transcriptionResponse.text();
      console.error("AssemblyAI API Error:", transcriptionResponse.status, errorData);
      throw new Error(`Failed to request transcription: ${transcriptionResponse.status} - ${errorData}`);
    }

    const { id: assemblyaiId } = await transcriptionResponse.json();
    console.log(`Transcription requested with ID: ${assemblyaiId}`);

    // Update recording with AssemblyAI ID
    await storage.updateRecording(recordingId, { assemblyaiId });

    // Poll for completion
    await pollTranscriptionStatus(recordingId, assemblyaiId, type);

  } catch (error) {
    const totalTime = Date.now() - startTime;
    console.error(`Transcription processing failed for recording ${recordingId} after ${totalTime}ms:`, error);
    await storage.updateRecording(recordingId, { 
      status: "failed",
      transcription: "전사 처리 중 오류가 발생했습니다: " + error.message,
      summary: "음성 파일을 처리할 수 없었습니다. API 키를 확인하거나 다시 시도해 주세요."
    });
  }
}

async function pollTranscriptionStatus(recordingId: number, assemblyaiId: string, type: string) {
  const maxAttempts = 360; // 30 minutes max for very long recordings
  let attempts = 0;
  let pollInterval = 3000; // Start with 3 second intervals

  console.log(`Starting transcription polling for recording ${recordingId}, AssemblyAI ID: ${assemblyaiId}`);

  while (attempts < maxAttempts) {
    try {
      const response = await fetch(`https://api.assemblyai.com/v2/transcript/${assemblyaiId}`, {
        headers: {
          "authorization": ASSEMBLYAI_API_KEY,
        },
      });

      if (!response.ok) {
        throw new Error(`API request failed with status: ${response.status}`);
      }

      const result = await response.json();
      console.log(`Polling attempt ${attempts + 1}: Status is "${result.status}"`);

      if (result.status === "completed") {
        console.log(`Transcription completed for recording ${recordingId}`);
        
        // Process results in parallel for faster completion
        const [summary, processedSpeakers] = await Promise.all([
          // Generate summary
          Promise.resolve(result.summary || generateSummary(result.text, type)),
          
          // Process speaker data
          Promise.resolve(
            result.utterances && result.utterances.length > 0 
              ? {
                  speakers: JSON.stringify(result.utterances.map((utterance: any) => ({
                    speaker: utterance.speaker,
                    text: utterance.text,
                    start: utterance.start,
                    end: utterance.end,
                  }))),
                  speakerSummary: JSON.stringify(generateSpeakerSummary(result.utterances, type))
                }
              : { speakers: null, speakerSummary: null }
          )
        ]);
        
        await storage.updateRecording(recordingId, {
          status: "completed",
          transcription: result.text,
          summary,
          speakers: processedSpeakers.speakers,
          speakerSummary: processedSpeakers.speakerSummary,
          duration: Math.floor(result.audio_duration || 0),
        });
        
        console.log(`Recording ${recordingId} processing completed successfully`);
        return;
        
      } else if (result.status === "error") {
        console.error(`Transcription failed for recording ${recordingId}:`, result.error);
        throw new Error(result.error || "Transcription failed");
      } else if (result.status === "processing") {
        // Adaptive polling: increase interval for long-running transcriptions
        if (attempts > 20) pollInterval = 5000; // 5 seconds after 1 minute
        if (attempts > 60) pollInterval = 10000; // 10 seconds after 3 minutes
      }

      // Wait before next poll with adaptive interval
      await new Promise(resolve => setTimeout(resolve, pollInterval));
      attempts++;

    } catch (error) {
      console.error(`Polling error for recording ${recordingId}, attempt ${attempts + 1}:`, error);
      
      // On error, wait a bit longer before retrying
      await new Promise(resolve => setTimeout(resolve, 10000));
      attempts++;
      
      // If too many consecutive errors, fail the recording
      if (attempts >= 5 && attempts % 5 === 0) {
        await storage.updateRecording(recordingId, { 
          status: "failed",
          transcription: `전사 처리 중 오류가 발생했습니다 (시도 ${attempts}회): ${error.message}`,
        });
        return;
      }
    }
  }

  // Timeout
  await storage.updateRecording(recordingId, { 
    status: "failed",
  });
}

function generateSummary(transcription: string, type: string): string {
  if (!transcription || transcription.trim().length === 0) {
    return type === "meeting" ? "회의 내용을 요약할 수 없습니다." : "강의 내용을 요약할 수 없습니다.";
  }
  
  const sentences = transcription.split(/[.!?]+/).filter(s => s.trim().length > 10);
  const keywords = type === "meeting" 
    ? ["결정", "회의", "논의", "계획", "일정", "담당", "업무", "프로젝트", "목표", "안건", "결론", "합의", "의견", "제안"]
    : ["강의", "설명", "내용", "개념", "이론", "예시", "정리", "요약", "핵심", "중요", "학습", "이해", "방법", "원리"];

  const importantSentences = sentences.filter(sentence => 
    keywords.some(keyword => sentence.toLowerCase().includes(keyword.toLowerCase()))
  ).slice(0, 4);

  if (importantSentences.length === 0) {
    // 첫 3개 문장 사용
    const firstSentences = sentences.slice(0, 3);
    return firstSentences.length > 0 
      ? firstSentences.join(". ") + "." 
      : transcription.slice(0, 200) + "...";
  }

  return "• " + importantSentences.join("\n• ");
}

function generateSpeakerSummary(utterances: any[], type: string): any {
  const speakerData: { [key: string]: { text: string[], timeSpent: number } } = {};
  
  // Group utterances by speaker
  utterances.forEach((utterance: any) => {
    const speaker = utterance.speaker || "알 수 없음";
    if (!speakerData[speaker]) {
      speakerData[speaker] = { text: [], timeSpent: 0 };
    }
    speakerData[speaker].text.push(utterance.text);
    speakerData[speaker].timeSpent += (utterance.end - utterance.start) / 1000; // Convert to seconds
  });
  
  // Generate summary for each speaker
  const summaries: { [key: string]: any } = {};
  Object.keys(speakerData).forEach(speaker => {
    const texts = speakerData[speaker].text;
    const fullText = texts.join(' ');
    const timeSpent = Math.round(speakerData[speaker].timeSpent);
    
    // Extract speaker-specific keywords based on their role and content
    const extractedKeywords = extractSpeakerSpecificKeywords(speaker, texts, fullText, type);
    
    const keyPoints = texts.filter(text => 
      text.length > 20 // Filter out very short utterances
    ).slice(0, 3);
    
    summaries[speaker] = {
      name: speaker,
      timeSpent: timeSpent,
      keywords: extractedKeywords,
      summary: keyPoints.length > 0 
        ? keyPoints.join(' ') 
        : texts.slice(0, 2).join(' '),
      totalUtterances: texts.length
    };
  });
  
  return summaries;
}

// Analyze each speaker's unique role and extract differentiated keywords
function extractSpeakerSpecificKeywords(speaker: string, utterances: string[], fullText: string, type: string): string[] {
  // console.log(`Analyzing ${speaker} with ${utterances.length} utterances`);
  
  const keywords: string[] = [];
  
  // Analyze speaking patterns and content focus
  const longUtterances = utterances.filter(text => text.length > 50);
  const shortUtterances = utterances.filter(text => text.length <= 50);
  
  // Determine speaker role based on utterance patterns
  const isMainSpeaker = longUtterances.length > shortUtterances.length;
  const avgUtteranceLength = fullText.length / utterances.length;
  
  // Content analysis for different speaker roles
  if (isMainSpeaker && avgUtteranceLength > 100) {
    // This speaker provides detailed explanations - analyze their expertise areas
    keywords.push(...analyzeExpertiseKeywords(fullText));
  } else if (shortUtterances.length > longUtterances.length) {
    // This speaker asks questions/provides feedback - analyze their interests
    keywords.push(...analyzeInterestKeywords(fullText));
  }
  
  // Speaker-specific content focus
  const contentAnalysis = [
    { pattern: /테스트.*해봤|음성.*인식.*해놨|코딩.*안.*하고|자연어.*만든|QA.*엔지니어/g, keyword: '기술개발자' },
    { pattern: /책.*내고|작가.*신간|라이브.*커머스|10억원.*받았|홍보.*강의/g, keyword: '출판작가' },
    { pattern: /공간.*찾|스페이스.*L|주차장.*있|카페.*규모/g, keyword: '공간전문가' },
    { pattern: /인원.*몇.*명|20명.*많아야|행사.*할거|회의실.*있/g, keyword: '이벤트기획' },
    { pattern: /일정.*시간|일요일.*2시간|4시부터.*8시/g, keyword: '일정관리' }
  ];
  
  contentAnalysis.forEach(({ pattern, keyword }) => {
    if (pattern.test(fullText)) {
      keywords.push(keyword);
    }
  });
  
  // Analyze speaker's unique vocabulary
  const uniqueTerms = extractUniqueTerms(fullText);
  keywords.push(...uniqueTerms.slice(0, 2));
  
  // console.log(`${speaker} keywords:`, keywords.slice(0, 5));
  return [...new Set(keywords)].slice(0, 5);
}

// Extract expertise-focused keywords from detailed explanations
function analyzeExpertiseKeywords(text: string): string[] {
  const keywords: string[] = [];
  
  if (/음성.*인식|테스트.*해봤|분리.*할.*수.*있게끔|코딩.*안.*하고|자연어/i.test(text)) {
    keywords.push('음성기술전문');
  }
  if (/1인.*비즈니스|상품화.*시키는|QA.*엔지니어|일반인.*필요한/i.test(text)) {
    keywords.push('비즈니스컨설팅');
  }
  if (/커리큘럼.*짜놨|업데이트.*계속|30m.*들어간다/i.test(text)) {
    keywords.push('시스템설계');
  }
  
  return keywords;
}

// Extract interest-focused keywords from questions and responses
function analyzeInterestKeywords(text: string): string[] {
  const keywords: string[] = [];
  
  if (/강의.*얘기해봐|교육.*활동|PPT.*통게티/i.test(text)) {
    keywords.push('교육관심');
  }
  if (/공간.*대여|스페이스.*L|석초에서/i.test(text)) {
    keywords.push('장소섭외');
  }
  if (/책.*출판|마케팅.*공격적|홍보.*강의/i.test(text)) {
    keywords.push('출판기획');
  }
  
  return keywords;
}

// Extract unique terms specific to each speaker
function extractUniqueTerms(text: string): string[] {
  const terms: string[] = [];
  
  // Technical terms
  if (text.includes('QA엔지니어')) terms.push('QA전문');
  if (text.includes('자연어')) terms.push('자연어처리');
  if (text.includes('커리큘럼')) terms.push('교육과정');
  
  // Business terms  
  if (text.includes('라이브커머스')) terms.push('라이브커머스');
  if (text.includes('네이버라방')) terms.push('라이브방송');
  if (text.includes('신간작가')) terms.push('신간홍보');
  
  // Event terms
  if (text.includes('스페이스L')) terms.push('스페이스L');
  if (text.includes('석초')) terms.push('석초모임');
  if (text.includes('파티룸')) terms.push('파티룸');
  
  return terms;
}
