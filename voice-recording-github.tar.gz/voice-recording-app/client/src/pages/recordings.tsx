import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Mic, Clock, FileText, Trash2, ArrowLeft, Search, Edit2, Check, X } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Recording } from "@shared/schema";

export default function RecordingsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [editingTitle, setEditingTitle] = useState<{ [key: number]: boolean }>({});
  const [newTitles, setNewTitles] = useState<{ [key: number]: string }>({});
  const { toast } = useToast();
  
  const { data: recordings, isLoading } = useQuery<Recording[]>({
    queryKey: ["/api/recordings"],
  });

  const filteredRecordings = recordings?.filter(recording => {
    if (!searchTerm) return true;
    
    const searchLower = searchTerm.toLowerCase();
    return (
      recording.title.toLowerCase().includes(searchLower) ||
      recording.transcription?.toLowerCase().includes(searchLower) ||
      recording.summary?.toLowerCase().includes(searchLower) ||
      (recording.type === "meeting" ? "회의" : "강의").includes(searchLower)
    );
  }) || [];

  // Title update mutation
  const updateTitleMutation = useMutation({
    mutationFn: async ({ id, title }: { id: number; title: string }) => {
      const response = await fetch(`/api/recordings/${id}/title`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ title }),
      });
      if (!response.ok) throw new Error("Failed to update title");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recordings"] });
      toast({
        title: "제목 변경 완료",
        description: "녹음 제목이 성공적으로 변경되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "제목 변경 실패",
        description: "제목 변경 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = async (id: number) => {
    if (!confirm("이 녹음을 삭제하시겠습니까?")) return;
    
    try {
      const response = await fetch(`/api/recordings/${id}`, {
        method: "DELETE",
      });
      
      if (response.ok) {
        queryClient.invalidateQueries({ queryKey: ["/api/recordings"] });
        toast({
          title: "삭제 완료",
          description: "녹음이 성공적으로 삭제되었습니다.",
        });
      }
    } catch (error) {
      console.error("삭제 실패:", error);
      toast({
        title: "삭제 실패",
        description: "녹음 삭제 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    }
  };

  const startEditingTitle = (recordingId: number, currentTitle: string) => {
    setEditingTitle(prev => ({ ...prev, [recordingId]: true }));
    setNewTitles(prev => ({ ...prev, [recordingId]: currentTitle }));
  };

  const cancelEditingTitle = (recordingId: number) => {
    setEditingTitle(prev => ({ ...prev, [recordingId]: false }));
    setNewTitles(prev => {
      const updated = { ...prev };
      delete updated[recordingId];
      return updated;
    });
  };

  const saveTitle = (recordingId: number) => {
    const newTitle = newTitles[recordingId]?.trim();
    if (!newTitle) {
      toast({
        title: "제목 입력 필요",
        description: "제목을 입력해주세요.",
        variant: "destructive",
      });
      return;
    }
    
    updateTitleMutation.mutate({ id: recordingId, title: newTitle });
    setEditingTitle(prev => ({ ...prev, [recordingId]: false }));
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins > 0) {
      return `${mins}분 ${secs}초`;
    }
    return `${secs}초`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ko-KR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      weekday: "short",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-slate-600">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  홈으로
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-slate-900">전체 녹음</h1>
                <p className="text-sm text-slate-500">
                  총 {recordings?.length || 0}개의 녹음
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="녹음 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-3 bg-slate-200 rounded"></div>
                    <div className="h-3 bg-slate-200 rounded w-2/3"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredRecordings.length === 0 ? (
          <div className="text-center py-12">
            <Mic className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">
              {searchTerm ? "검색 결과가 없습니다" : "녹음이 없습니다"}
            </h3>
            <p className="text-slate-500 mb-6">
              {searchTerm
                ? "다른 검색어를 시도해보세요"
                : "첫 번째 녹음을 시작해보세요"}
            </p>
            {!searchTerm && (
              <Link href="/">
                <Button>
                  <Mic className="w-4 h-4 mr-2" />
                  녹음 시작
                </Button>
              </Link>
            )}
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredRecordings.map((recording) => (
              <Card key={recording.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      {editingTitle[recording.id] ? (
                        <div className="space-y-2">
                          <Input
                            value={newTitles[recording.id] || ""}
                            onChange={(e) => setNewTitles(prev => ({ 
                              ...prev, 
                              [recording.id]: e.target.value 
                            }))}
                            className="text-lg font-medium"
                            placeholder="녹음 제목 입력..."
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                saveTitle(recording.id);
                              } else if (e.key === "Escape") {
                                cancelEditingTitle(recording.id);
                              }
                            }}
                            autoFocus
                          />
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              onClick={() => saveTitle(recording.id)}
                              disabled={updateTitleMutation.isPending}
                            >
                              <Check className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => cancelEditingTitle(recording.id)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="group flex items-start space-x-2">
                          <div 
                            className="text-lg font-medium text-slate-900 line-clamp-2 flex-1 cursor-pointer hover:text-blue-600 transition-colors"
                            onClick={() => startEditingTitle(recording.id, recording.title)}
                            title="클릭하여 제목 편집"
                          >
                            {recording.title}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => startEditingTitle(recording.id, recording.title)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-400 hover:text-slate-600 flex-shrink-0"
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                      <p className="text-sm text-slate-500 mt-1">
                        {formatDate(recording.createdAt.toString())}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(recording.id)}
                      className="text-slate-400 hover:text-red-600 ml-2"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center space-x-2 mt-2">
                    <Badge variant={recording.type === "meeting" ? "default" : "secondary"}>
                      {recording.type === "meeting" ? "회의" : "강의"}
                    </Badge>
                    {recording.duration && (
                      <Badge variant="outline" className="text-xs">
                        <Clock className="w-3 h-3 mr-1" />
                        {formatDuration(recording.duration)}
                      </Badge>
                    )}
                    <Badge
                      variant={
                        recording.status === "completed"
                          ? "default"
                          : recording.status === "processing"
                          ? "secondary"
                          : "destructive"
                      }
                    >
                      {recording.status === "completed"
                        ? "완료"
                        : recording.status === "processing"
                        ? "처리중"
                        : "실패"}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent>
                  {recording.status === "completed" ? (
                    <div className="space-y-3">
                      {recording.summary && (
                        <div>
                          <h4 className="text-sm font-medium text-slate-700 mb-1">요약</h4>
                          <p className="text-sm text-slate-600 line-clamp-3">
                            {recording.summary}
                          </p>
                        </div>
                      )}
                      
                      {recording.transcription && (
                        <div>
                          <h4 className="text-sm font-medium text-slate-700 mb-1">전사 내용</h4>
                          <p className="text-sm text-slate-600 line-clamp-2">
                            {recording.transcription}
                          </p>
                        </div>
                      )}
                      
                      <Link href={`/recording/${recording.id}`}>
                        <Button size="sm" className="w-full mt-3">
                          <FileText className="w-4 h-4 mr-2" />
                          상세 보기
                        </Button>
                      </Link>
                    </div>
                  ) : recording.status === "processing" ? (
                    <div className="text-center py-4">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
                      <p className="text-sm text-slate-600">처리 중...</p>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-sm text-red-600">처리 실패</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}