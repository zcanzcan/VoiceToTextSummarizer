import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { ArrowLeft, Clock, User, FileText, Download, Trash2, Edit2, Check, X, Sparkles, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect, useMemo } from "react";
import { Textarea } from "@/components/ui/textarea";
import type { Recording } from "@shared/schema";

export default function RecordingDetailPage() {
  const [, params] = useRoute("/recording/:id");
  const recordingId = params?.id ? parseInt(params.id) : null;
  const { toast } = useToast();
  const [editingSpeakerNames, setEditingSpeakerNames] = useState<{[key: string]: boolean}>({});
  const [speakerNameInputs, setSpeakerNameInputs] = useState<{[key: string]: string}>({});
  const [editingTranscription, setEditingTranscription] = useState(false);
  const [newTranscription, setNewTranscription] = useState("");
  const [isRefiningTranscription, setIsRefiningTranscription] = useState(false);

  const { data: recording, isLoading } = useQuery<Recording>({
    queryKey: [`/api/recordings/${recordingId}`],
    enabled: !!recordingId,
  });

  // Mutation for updating speaker names - moved to top level
  const updateSpeakerNamesMutation = useMutation({
    mutationFn: async (names: {[key: string]: string}) => {
      const response = await fetch(`/api/recordings/${recordingId}/speakers`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ speakerNames: names }),
      });
      if (!response.ok) throw new Error("Failed to update speaker names");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/recordings/${recordingId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/recordings"] });
      toast({
        title: "화자 이름이 저장되었습니다",
        description: "변경사항이 모든 화자별 분석에 반영되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "저장 실패",
        description: "화자 이름 저장 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // Mutation for updating transcription content
  const updateTranscriptionMutation = useMutation({
    mutationFn: async (transcription: string) => {
      const response = await fetch(`/api/recordings/${recordingId}/content`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ transcription }),
      });
      if (!response.ok) throw new Error("Failed to update transcription");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/recordings/${recordingId}`] });
      setEditingTranscription(false);
      toast({
        title: "전사 내용이 저장되었습니다",
        description: "변경사항이 반영되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "저장 실패",
        description: "전사 내용 저장 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // Mutation for AI-powered transcription refinement
  const refineTranscriptionMutation = useMutation({
    mutationFn: async (originalText: string) => {
      const response = await fetch(`/api/recordings/${recordingId}/refine`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ transcription: originalText }),
      });
      if (!response.ok) throw new Error("Failed to refine transcription");
      return response.json();
    },
    onSuccess: (data) => {
      setNewTranscription(data.refinedTranscription);
      setEditingTranscription(true);
      toast({
        title: "AI 정제 완료",
        description: "Claude가 전사 내용을 개선했습니다. 검토 후 저장하세요.",
      });
    },
    onError: () => {
      toast({
        title: "정제 실패",
        description: "AI 정제 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // Mutation for regenerating speaker analysis
  const regenerateAnalysisMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/recordings/${recordingId}/regenerate-analysis`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      if (!response.ok) throw new Error("Failed to regenerate analysis");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/recordings/${recordingId}`] });
      toast({
        title: "화자별 분석 재생성 완료",
        description: "개선된 알고리즘으로 화자별 키워드가 업데이트되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "재생성 실패",
        description: "화자별 분석 재생성 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // Helper functions moved before use
  const getSpeakers = (speakersJson: string) => {
    try {
      return JSON.parse(speakersJson);
    } catch {
      return [];
    }
  };

  const getSpeakerSummary = (speakerSummaryJson: string) => {
    try {
      return JSON.parse(speakerSummaryJson);
    } catch {
      return {};
    }
  };

  const getSpeakerNames = (speakerNamesJson: string) => {
    try {
      return JSON.parse(speakerNamesJson);
    } catch {
      return {};
    }
  };

  // Data parsing - using useMemo to ensure stable references
  const speakers = useMemo(() => recording?.speakers ? getSpeakers(recording.speakers) : [], [recording?.speakers]);
  const speakerSummary = useMemo(() => recording?.speakerSummary ? getSpeakerSummary(recording.speakerSummary) : {}, [recording?.speakerSummary]);
  const speakerNames = useMemo(() => recording?.speakerNames ? getSpeakerNames(recording.speakerNames) : {}, [recording?.speakerNames]);

  // Initialize speaker name inputs when data loads
  useEffect(() => {
    if (Object.keys(speakerSummary).length > 0) {
      const initialInputs: {[key: string]: string} = {};
      Object.keys(speakerSummary).forEach(speaker => {
        initialInputs[speaker] = speakerNames[speaker] || speaker.replace('Speaker ', '화자 ');
      });
      setSpeakerNameInputs(initialInputs);
    }
  }, [speakerSummary, speakerNames]);

  // Initialize transcription text when data loads
  useEffect(() => {
    if (recording?.transcription && !newTranscription) {
      setNewTranscription(recording.transcription);
    }
  }, [recording?.transcription]);

  const handleDelete = async () => {
    if (!recording || !confirm("이 녹음을 삭제하시겠습니까?")) return;
    
    try {
      const response = await fetch(`/api/recordings/${recording.id}`, {
        method: "DELETE",
      });
      
      if (response.ok) {
        queryClient.invalidateQueries({ queryKey: ["/api/recordings"] });
        window.location.href = "/recordings";
      }
    } catch (error) {
      console.error("삭제 실패:", error);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ko-KR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-slate-200 rounded w-1/3"></div>
            <div className="h-64 bg-slate-200 rounded"></div>
            <div className="h-32 bg-slate-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!recording) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <div className="max-w-4xl mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-slate-900 mb-4">녹음을 찾을 수 없습니다</h1>
          <Link href="/recordings">
            <Button>녹음 목록으로 돌아가기</Button>
          </Link>
        </div>
      </div>
    );
  }





  const handleSpeakerNameEdit = (speaker: string) => {
    setEditingSpeakerNames(prev => ({ ...prev, [speaker]: true }));
  };

  const handleSpeakerNameSave = (speaker: string) => {
    const newName = speakerNameInputs[speaker];
    if (newName && newName.trim()) {
      const updatedNames = { ...speakerNames, [speaker]: newName.trim() };
      updateSpeakerNamesMutation.mutate(updatedNames);
    }
    setEditingSpeakerNames(prev => ({ ...prev, [speaker]: false }));
  };

  const handleSpeakerNameCancel = (speaker: string) => {
    setSpeakerNameInputs(prev => ({
      ...prev,
      [speaker]: speakerNames[speaker] || speaker.replace('Speaker ', '화자 ')
    }));
    setEditingSpeakerNames(prev => ({ ...prev, [speaker]: false }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/recordings">
                <Button variant="ghost" size="sm" className="text-slate-600">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  목록으로
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-slate-900">{recording.title}</h1>
                <p className="text-sm text-slate-500">{recording.createdAt ? formatDate(recording.createdAt.toString()) : '날짜 정보 없음'}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleDelete}>
                <Trash2 className="w-4 h-4 mr-2" />
                삭제
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        {/* Recording Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              녹음 정보
              <div className="flex items-center space-x-2">
                <Badge variant={recording.type === "meeting" ? "default" : "secondary"}>
                  {recording.type === "meeting" ? "회의" : "강의"}
                </Badge>
                {recording.duration && (
                  <Badge variant="outline">
                    <Clock className="w-3 h-3 mr-1" />
                    {formatDuration(recording.duration)}
                  </Badge>
                )}
                <Badge
                  variant={
                    recording.status === "completed"
                      ? "default"
                      : recording.status === "processing"
                      ? "secondary"
                      : "destructive"
                  }
                >
                  {recording.status === "completed"
                    ? "완료"
                    : recording.status === "processing"
                    ? "처리중"
                    : "실패"}
                </Badge>
              </div>
            </CardTitle>
          </CardHeader>
        </Card>

        {recording.status === "completed" && (
          <>
            {/* Summary */}
            {recording.summary && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    요약
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                    {recording.summary}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Speaker Analysis */}
            {speakers.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <User className="w-5 h-5 mr-2" />
                      화자별 분석
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => regenerateAnalysisMutation.mutate()}
                      disabled={regenerateAnalysisMutation.isPending}
                    >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      {regenerateAnalysisMutation.isPending ? '재생성 중...' : '분석 재생성'}
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(speakerSummary).map(([speaker, data]: [string, any]) => {
                    const displayName = speakerNames[speaker] || speaker.replace('Speaker ', '화자 ');
                    const isEditing = editingSpeakerNames[speaker];
                    return (
                      <div key={speaker} className="border border-slate-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2 flex-1">
                            {isEditing ? (
                              <div className="flex items-center space-x-2 flex-1">
                                <Input
                                  value={speakerNameInputs[speaker] || ''}
                                  onChange={(e) => setSpeakerNameInputs(prev => ({
                                    ...prev,
                                    [speaker]: e.target.value
                                  }))}
                                  placeholder="화자 이름 입력"
                                  className="flex-1"
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      handleSpeakerNameSave(speaker);
                                    } else if (e.key === 'Escape') {
                                      handleSpeakerNameCancel(speaker);
                                    }
                                  }}
                                />
                                <Button
                                  size="sm"
                                  onClick={() => handleSpeakerNameSave(speaker)}
                                  disabled={updateSpeakerNamesMutation.isPending}
                                >
                                  <Check className="h-3 w-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleSpeakerNameCancel(speaker)}
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                            ) : (
                              <div className="flex items-center space-x-2">
                                <h4 className="font-medium text-slate-900">
                                  {displayName}
                                </h4>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleSpeakerNameEdit(speaker)}
                                  className="text-slate-500 hover:text-slate-700"
                                >
                                  <Edit2 className="h-3 w-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                          {data.timeSpent && (
                            <Badge variant="outline">
                              {Math.floor(data.timeSpent / 60)}분 {data.timeSpent % 60}초
                            </Badge>
                          )}
                        </div>
                        {data.keywords && data.keywords.length > 0 && (
                          <div className="mb-3">
                            <p className="text-sm text-slate-600 mb-2">주요 키워드:</p>
                            <div className="flex flex-wrap gap-1">
                              {data.keywords.map((keyword: string, idx: number) => (
                                <Badge key={idx} variant="secondary" className="text-xs">
                                  {keyword}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        {data.summary && (
                          <p className="text-sm text-slate-700">{data.summary}</p>
                        )}
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            )}

            {/* Full Transcript */}
            {recording.transcription && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    전체 전사 내용
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setEditingTranscription(!editingTranscription)}
                      >
                        <Edit2 className="mr-2 h-4 w-4" />
                        {editingTranscription ? "완료" : "편집"}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => refineTranscriptionMutation.mutate(recording.transcription || "")}
                        disabled={refineTranscriptionMutation.isPending}
                      >
                        <Sparkles className="mr-2 h-4 w-4" />
                        {refineTranscriptionMutation.isPending ? 'AI 정제 중...' : 'AI 정제'}
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {editingTranscription ? (
                      <div className="space-y-4">
                        <Textarea
                          value={newTranscription}
                          onChange={(e) => setNewTranscription(e.target.value)}
                          placeholder="전사 내용을 입력하세요..."
                          rows={15}
                          className="w-full font-mono text-sm"
                        />
                        <div className="flex justify-end space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setNewTranscription(recording.transcription || "");
                              setEditingTranscription(false);
                            }}
                          >
                            <X className="mr-1 h-3 w-3" />
                            취소
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => updateTranscriptionMutation.mutate(newTranscription)}
                            disabled={updateTranscriptionMutation.isPending}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            <Check className="mr-2 h-4 w-4" />
                            {updateTranscriptionMutation.isPending ? '저장 중...' : '저장'}
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div>
                        {speakers.length > 0 ? (
                          <div className="space-y-4">
                            {speakers.map((utterance: any, idx: number) => {
                              const displayName = speakerNames[utterance.speaker] || utterance.speaker.replace('Speaker ', '화자 ');
                              return (
                                <div key={idx} className="flex space-x-3">
                                  <div className="flex-shrink-0">
                                    <Badge variant="outline" className="text-xs">
                                      {displayName}
                                    </Badge>
                                  </div>
                                  <div className="flex-1">
                                    <p className="text-slate-700 leading-relaxed">
                                      {utterance.text}
                                    </p>
                                    <p className="text-xs text-slate-500 mt-1">
                                      {Math.floor(utterance.start / 1000)}초 - {Math.floor(utterance.end / 1000)}초
                                    </p>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                            {recording.transcription}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {recording.status === "processing" && (
          <Card>
            <CardContent className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <h3 className="text-lg font-medium text-slate-900 mb-2">처리 중...</h3>
              <p className="text-slate-600">녹음을 전사하고 분석하는 중입니다.</p>
            </CardContent>
          </Card>
        )}

        {recording.status === "failed" && (
          <Card>
            <CardContent className="text-center py-8">
              <h3 className="text-lg font-medium text-red-600 mb-2">처리 실패</h3>
              <p className="text-slate-600">녹음 처리 중 오류가 발생했습니다.</p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}