import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, Mic, Brain, FileText, Users, Zap, Clock } from "lucide-react";

interface ProcessingScreenProps {
  duration?: number;
}

export default function ProcessingScreen({ duration = 0 }: ProcessingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [startTime] = useState(Date.now());
  const [elapsedTime, setElapsedTime] = useState(0);
  
  const steps = [
    { icon: Mic, label: "음성 파일 업로드", description: "최적화된 속도로 파일 전송 중..." },
    { icon: Brain, label: "AI 고속 음성 분석", description: "Speed Boost로 빠른 전사 처리 중..." },
    { icon: Users, label: "화자 구분 및 분석", description: "실시간 화자 분리 및 발화 분석 중..." },
    { icon: FileText, label: "스마트 요약 생성", description: "병렬 처리로 요약 및 키워드 추출 중..." },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      setElapsedTime(elapsed);
      
      setProgress((prev) => {
        if (prev >= 100) {
          return 100;
        }
        
        // 개선된 진행률 계산 (장시간 녹음에 최적화)
        const durationMinutes = duration / 60;
        let progressIncrement;
        
        if (durationMinutes <= 5) {
          // 5분 이하: 빠른 처리
          progressIncrement = Math.random() * 4 + 2;
        } else if (durationMinutes <= 30) {
          // 30분 이하: 중간 속도
          progressIncrement = Math.random() * 2 + 1;
        } else {
          // 30분 이상: 안정적인 진행
          progressIncrement = Math.random() * 1.5 + 0.5;
        }
        
        const newProgress = Math.min(prev + progressIncrement, 95);
        
        // 단계 업데이트 (더 자연스럽게)
        const stepIndex = Math.floor(newProgress / 23);
        setCurrentStep(Math.min(stepIndex, steps.length - 1));
        
        return newProgress;
      });
    }, 1500); // 1.5초마다 업데이트

    return () => clearInterval(interval);
  }, [duration, startTime]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // 개선된 예상 시간 계산 (Speed Boost 적용)
  const getEstimatedTime = (recordingDuration: number) => {
    const minutes = recordingDuration / 60;
    if (minutes <= 5) return Math.max(20, Math.floor(recordingDuration * 0.2)); // 20% 시간
    if (minutes <= 30) return Math.max(30, Math.floor(recordingDuration * 0.25)); // 25% 시간  
    return Math.max(60, Math.floor(recordingDuration * 0.3)); // 30% 시간
  };

  const estimatedTime = getEstimatedTime(duration);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-lg">
            <div className="relative">
              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              <Zap className="w-3 h-3 text-yellow-500 absolute -top-1 -right-1" />
            </div>
            고속 음성 처리 중
          </CardTitle>
          {duration > 0 && (
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">
                녹음 시간: {formatDuration(duration)}
              </p>
              <p className="text-xs text-green-600 font-medium flex items-center justify-center gap-1">
                <Zap className="w-3 h-3" />
                Speed Boost 적용 | 예상 시간: {formatDuration(estimatedTime)}
              </p>
            </div>
          )}
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Progress value={progress} className="w-full" />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>{Math.round(progress)}% 완료</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatDuration(elapsedTime)}
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = index === currentStep;
              const isCompleted = index < currentStep;

              return (
                <div
                  key={index}
                  className={`flex items-start gap-3 p-3 rounded-lg transition-all ${
                    isActive
                      ? "bg-blue-50 border border-blue-200"
                      : isCompleted
                      ? "bg-green-50 border border-green-200"
                      : "bg-gray-50 border border-gray-200"
                  }`}
                >
                  <div
                    className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                      isActive
                        ? "bg-blue-500 text-white"
                        : isCompleted
                        ? "bg-green-500 text-white"
                        : "bg-gray-300 text-gray-500"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`font-medium text-sm ${
                        isActive || isCompleted ? "text-gray-900" : "text-gray-500"
                      }`}
                    >
                      {step.label}
                    </p>
                    <p
                      className={`text-xs mt-1 ${
                        isActive
                          ? "text-blue-600"
                          : isCompleted
                          ? "text-green-600"
                          : "text-gray-400"
                      }`}
                    >
                      {step.description}
                    </p>
                  </div>
                  {isActive && (
                    <Loader2 className="w-4 h-4 animate-spin text-blue-500 flex-shrink-0" />
                  )}
                </div>
              );
            })}
          </div>

          {duration > 1800 && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <p className="text-xs text-amber-800 text-center">
                <Zap className="w-3 h-3 inline mr-1" />
                30분 이상의 장시간 녹음도 Speed Boost로 빠르게 처리됩니다
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}