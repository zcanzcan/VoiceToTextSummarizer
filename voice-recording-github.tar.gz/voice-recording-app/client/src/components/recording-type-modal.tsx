import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { GraduationCap, Users } from "lucide-react";

interface RecordingTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTypeSelected: (type: "lecture" | "meeting") => void;
}

export default function RecordingTypeModal({ isOpen, onClose, onTypeSelected }: RecordingTypeModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-slate-900">녹음 유형 선택</DialogTitle>
          <DialogDescription className="text-slate-600">
            녹음하실 내용의 유형을 선택해주세요. 유형에 따라 최적화된 전사 및 요약을 제공합니다.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-3 mt-6">
          <button
            onClick={() => onTypeSelected("lecture")}
            className="w-full p-4 border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50 rounded-xl transition-all text-left group"
          >
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-emerald-100 group-hover:bg-emerald-200 rounded-lg flex items-center justify-center transition-colors">
                <GraduationCap className="text-emerald-600 text-lg" />
              </div>
              <div>
                <h4 className="font-semibold text-slate-900">강의용</h4>
                <p className="text-sm text-slate-600">강의, 프레젠테이션, 교육 콘텐츠</p>
              </div>
            </div>
          </button>
          
          <button
            onClick={() => onTypeSelected("meeting")}
            className="w-full p-4 border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50 rounded-xl transition-all text-left group"
          >
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-blue-100 group-hover:bg-blue-200 rounded-lg flex items-center justify-center transition-colors">
                <Users className="text-blue-600 text-lg" />
              </div>
              <div>
                <h4 className="font-semibold text-slate-900">회의용</h4>
                <p className="text-sm text-slate-600">회의, 토론, 브레인스토밍</p>
              </div>
            </div>
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
