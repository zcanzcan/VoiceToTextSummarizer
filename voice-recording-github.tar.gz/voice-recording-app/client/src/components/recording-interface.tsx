import { useState } from "react";
import { Mic } from "lucide-react";
import RecordingTypeModal from "./recording-type-modal";
import ProcessingScreen from "./processing-screen";
import ResultsDisplay from "./results-display";
import { useAudioRecorder } from "@/lib/audio-recorder";
import { queryClient } from "@/lib/queryClient";

type RecordingState = "idle" | "recording" | "processing" | "completed";

export default function RecordingInterface() {
  const [state, setState] = useState<RecordingState>("idle");
  const [showTypeModal, setShowTypeModal] = useState(false);
  const [recordingId, setRecordingId] = useState<number | null>(null);
  const [lastRecordingDuration, setLastRecordingDuration] = useState<number>(0);
  
  const {
    isRecording,
    recordingTime,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    isPaused,
    isBackgroundMode,
  } = useAudioRecorder({
    onRecordingComplete: async (audioBlob, type) => {
      setLastRecordingDuration(recordingTime);
      setState("processing");
      
      try {
        const formData = new FormData();
        formData.append("audio", audioBlob, "recording.wav");
        formData.append("type", type);

        const response = await fetch("/api/transcribe", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          throw new Error("Failed to upload recording");
        }

        const { recordingId } = await response.json();
        setRecordingId(recordingId);
        
        // Poll for completion and refresh recordings list
        pollForCompletion(recordingId);
        
        // Refresh the recordings list immediately
        queryClient.invalidateQueries({ queryKey: ["/api/recordings"] });
      } catch (error) {
        console.error("Upload error:", error);
        setState("idle");
      }
    },
  });

  const pollForCompletion = async (id: number) => {
    const poll = async () => {
      try {
        const response = await fetch(`/api/recordings/${id}/status`);
        const data = await response.json();
        
        if (data.status === "completed") {
          setState("completed");
        } else if (data.status === "failed") {
          setState("idle");
        } else {
          setTimeout(poll, 2000); // Poll every 2 seconds
        }
      } catch (error) {
        console.error("Polling error:", error);
        setState("idle");
      }
    };
    poll();
  };

  const handleStartRecording = () => {
    setShowTypeModal(true);
  };

  const handleTypeSelected = (type: "lecture" | "meeting") => {
    setShowTypeModal(false);
    startRecording(type);
    setState("recording");
  };

  const handleStopRecording = () => {
    stopRecording();
    setState("idle");
  };

  const handleNewRecording = () => {
    setState("idle");
    setRecordingId(null);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (state === "processing") {
    return <ProcessingScreen duration={lastRecordingDuration} />;
  }

  if (state === "completed" && recordingId) {
    return <ResultsDisplay recordingId={recordingId} onNewRecording={handleNewRecording} />;
  }

  return (
    <>
      <div className="text-center mb-12">
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200 p-8 mb-8">
          <h2 className="text-2xl font-semibold text-slate-900 mb-2">새로운 녹음 시작</h2>
          <p className="text-slate-600 mb-8">강의나 회의를 녹음하고 자동으로 텍스트로 변환하세요</p>
          
          {!isRecording ? (
            <div className="flex flex-col items-center space-y-6">
              <button
                onClick={handleStartRecording}
                className="w-24 h-24 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center shadow-lg transform hover:scale-105 transition-all duration-200 group"
              >
                <Mic className="text-white text-2xl group-hover:scale-110 transition-transform" />
              </button>
              <span className="text-lg font-medium text-slate-700">녹음 시작</span>
              <p className="text-sm text-slate-500 text-center max-w-md">
                {isBackgroundMode ? (
                  <span className="text-orange-600 font-medium">
                    백그라운드에서 녹음 중입니다
                  </span>
                ) : (
                  "녹음 시작 후 화면을 끄거나 다른 앱으로 이동해도 백그라운드에서 계속 녹음됩니다."
                )}
              </p>
            </div>
          ) : (
            <div className="mt-8 p-6 bg-red-50 rounded-xl border border-red-200">
              <div className="flex items-center justify-center space-x-4 mb-4">
                <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-red-700 font-medium">
                  {isPaused ? "일시정지됨" : "녹음 중..."}
                </span>
                <div className="text-slate-600 font-mono">
                  {formatTime(recordingTime)}
                </div>
              </div>
              
              {isBackgroundMode ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                  <p className="text-sm text-green-800 text-center font-medium">
                    🎙️ 백그라운드 녹음 진행 중
                    <br />
                    다른 앱을 자유롭게 사용하세요. 녹음은 계속됩니다.
                  </p>
                </div>
              ) : (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                  <p className="text-sm text-blue-800 text-center">
                    ✅ 백그라운드 녹음 지원 활성화됨
                    <br />
                    화면을 끄거나 다른 앱으로 이동해도 녹음이 중단되지 않습니다
                    <br />
                    <strong>종료 버튼을 누를 때까지 계속 녹음됩니다</strong>
                  </p>
                </div>
              )}
              
              <div className="flex items-center justify-center space-x-4">
                <button
                  onClick={isPaused ? resumeRecording : pauseRecording}
                  className="px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-lg transition-colors"
                >
                  {isPaused ? "계속" : "일시정지"}
                </button>
                <button
                  onClick={handleStopRecording}
                  className="px-6 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors font-medium"
                >
                  녹음 종료
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <RecordingTypeModal
        isOpen={showTypeModal}
        onClose={() => setShowTypeModal(false)}
        onTypeSelected={handleTypeSelected}
      />
    </>
  );
}
