import { useQuery, useMutation } from "@tanstack/react-query";
import { Recording } from "@shared/schema";
import { FileText, Download, FileDown, Plus, Users, Save, Clock, Search, Edit2, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";

interface ResultsDisplayProps {
  recordingId: number;
  onNewRecording: () => void;
}

export default function ResultsDisplay({ recordingId, onNewRecording }: ResultsDisplayProps) {
  // All state hooks at the top level - never conditional
  const { toast } = useToast();
  const [showSpeakerAnalysis, setShowSpeakerAnalysis] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSpeaker, setSelectedSpeaker] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(20);
  const [editingSpeakers, setEditingSpeakers] = useState(false);
  const [speakerNames, setSpeakerNames] = useState<{[key: string]: string}>({});
  const [editingTitle, setEditingTitle] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [editingTranscription, setEditingTranscription] = useState(false);
  const [newTranscription, setNewTranscription] = useState("");
  const [editingSummary, setEditingSummary] = useState(false);
  const [newSummary, setNewSummary] = useState("");

  // Query hook - always called
  const { data: recording, isLoading } = useQuery<Recording>({
    queryKey: [`/api/recordings/${recordingId}`],
  });

  // Parse data safely
  const speakers = recording?.speakers ? (() => {
    try { return JSON.parse(recording.speakers); } catch { return null; }
  })() : null;
  
  const speakerSummary = recording?.speakerSummary ? (() => {
    try { return JSON.parse(recording.speakerSummary); } catch { return null; }
  })() : null;
  
  const storedSpeakerNames = recording?.speakerNames ? (() => {
    try { return JSON.parse(recording.speakerNames); } catch { return {}; }
  })() : {};

  // Effect hooks - always called
  useEffect(() => {
    if (recording && speakers) {
      const uniqueSpeakers = Array.from(new Set(speakers.map((s: any) => s.speaker))) as string[];
      const initialNames: {[key: string]: string} = {};
      uniqueSpeakers.forEach(speaker => {
        initialNames[speaker] = (storedSpeakerNames as any)[speaker] || speaker.replace('Speaker ', '화자 ');
      });
      setSpeakerNames(initialNames);
    }
  }, [recording?.id, recording?.speakerNames]);

  useEffect(() => {
    if (recording && !newTitle) {
      setNewTitle(recording.title);
    }
  }, [recording?.title]);

  useEffect(() => {
    if (recording && !newTranscription) {
      setNewTranscription(recording.transcription || "");
    }
  }, [recording?.transcription]);

  useEffect(() => {
    if (recording && !newSummary) {
      setNewSummary(recording.summary || "");
    }
  }, [recording?.summary]);

  // Mutation hooks - always called
  const saveRecordingMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/recordings/${recordingId}/save`, {
        method: "POST",
      });
      if (!response.ok) throw new Error("Failed to save recording");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/recordings/${recordingId}`] });
      toast({
        title: "녹음이 저장되었습니다",
        description: "화자별 분석과 함께 영구 저장되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "저장 실패",
        description: "녹음 저장 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const updateSpeakerNamesMutation = useMutation({
    mutationFn: async (names: {[key: string]: string}) => {
      console.log("Updating speaker names:", names);
      const response = await fetch(`/api/recordings/${recordingId}/speakers`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ speakerNames: names }),
      });
      if (!response.ok) {
        const errorText = await response.text();
        console.error("Speaker update failed:", response.status, errorText);
        throw new Error(`Failed to update speaker names: ${response.status}`);
      }
      return response.json();
    },
    onSuccess: (data) => {
      console.log("Speaker names updated successfully:", data);
      queryClient.invalidateQueries({ queryKey: [`/api/recordings/${recordingId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/recordings"] });
      setEditingSpeakers(false);
      toast({
        title: "화자 이름이 저장되었습니다",
        description: "이제 언제든지 다시 수정할 수 있습니다.",
      });
    },
    onError: (error) => {
      console.error("Error updating speaker names:", error);
      toast({
        title: "화자 이름 저장 실패",
        description: "다시 시도해 주세요.",
        variant: "destructive",
      });
    },
  });

  const updateTitleMutation = useMutation({
    mutationFn: async (title: string) => {
      const response = await fetch(`/api/recordings/${recordingId}/title`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ title }),
      });
      if (!response.ok) throw new Error("Failed to update title");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/recordings/${recordingId}`] });
      setEditingTitle(false);
      toast({
        title: "제목이 업데이트되었습니다",
      });
    },
  });

  const updateContentMutation = useMutation({
    mutationFn: async ({ transcription, summary }: { transcription?: string; summary?: string }) => {
      const response = await fetch(`/api/recordings/${recordingId}/content`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ transcription, summary }),
      });
      if (!response.ok) throw new Error("Failed to update content");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/recordings/${recordingId}`] });
      setEditingTranscription(false);
      setEditingSummary(false);
      toast({
        title: "내용이 업데이트되었습니다",
        description: "변경사항이 저장되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "업데이트 실패",
        description: "내용 수정 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  // Helper functions
  const downloadTranscription = () => {
    if (!recording?.transcription) return;
    const element = document.createElement("a");
    const file = new Blob([recording.transcription], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `${recording.title}_전사본.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const exportSummary = () => {
    if (!recording?.summary) return;
    const element = document.createElement("a");
    const file = new Blob([recording.summary], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `${recording.title}_요약.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Conditional rendering based on state
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-slate-200 rounded w-1/3"></div>
            <div className="h-4 bg-slate-200 rounded w-1/2"></div>
            <div className="space-y-2">
              <div className="h-4 bg-slate-200 rounded"></div>
              <div className="h-4 bg-slate-200 rounded w-3/4"></div>
            </div>
            <div className="h-24 bg-slate-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (recording?.status === "failed") {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-8 text-center">
        <div className="text-red-500 mb-4">
          <FileText className="w-16 h-16 mx-auto" />
        </div>
        <h3 className="text-lg font-semibold text-slate-900 mb-2">전사 실패</h3>
        <p className="text-slate-600 mb-6">음성 파일 변환 중 오류가 발생했습니다. 다시 시도해 주세요.</p>
        <Button onClick={onNewRecording}>새 녹음 시작</Button>
      </div>
    );
  }

  if (!recording) {
    return (
      <div className="text-center py-8">
        <p className="text-slate-600">녹음을 찾을 수 없습니다.</p>
        <Button onClick={onNewRecording} className="mt-4">
          새 녹음 시작
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Title Section with Edit */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-4">
          {editingTitle ? (
            <div className="flex items-center space-x-2 flex-1">
              <Input
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="flex-1"
                placeholder="녹음 제목 입력"
              />
              <Button
                size="sm"
                onClick={() => updateTitleMutation.mutate(newTitle)}
                disabled={updateTitleMutation.isPending}
              >
                <Check className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setEditingTitle(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-semibold text-slate-900">{recording.title}</h2>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setEditingTitle(true)}
              >
                <Edit2 className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
        
        <div className="text-sm text-slate-600">
          {new Date(recording.createdAt).toLocaleString("ko-KR")} · {Math.floor(recording.duration / 60)}분 {recording.duration % 60}초
        </div>
      </div>

      {/* Status and Save Section */}
      {!recording.isSaved && (
        <div className="bg-yellow-50 rounded-xl shadow-lg border border-yellow-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-yellow-800 mb-2">녹음 완료 - 로그 기록</h3>
              <p className="text-yellow-700">
                {speakers ? `${Object.keys(speakerSummary || {}).length}명의 화자가 감지되었습니다.` : "전사가 완료되었습니다."} 
                저장 버튼을 눌러 화자별 분석과 함께 영구 저장하세요.
              </p>
            </div>
            <Button 
              onClick={() => saveRecordingMutation.mutate()}
              disabled={saveRecordingMutation.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              <Save className="mr-2 h-4 w-4" />
              저장하기
            </Button>
          </div>
        </div>
      )}

      {/* Speaker Analysis Section */}
      {speakers && speakerSummary && (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900 flex items-center">
              <Users className="text-slate-500 mr-2" />
              화자별 분석 ({Object.keys(speakerSummary).length}명)
            </h3>
            <div className="flex space-x-2">
              <Button 
                size="sm"
                variant="outline" 
                onClick={() => setEditingSpeakers(!editingSpeakers)}
              >
                <Edit2 className="mr-2 h-4 w-4" />
                {editingSpeakers ? "완료" : "이름 편집"}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowSpeakerAnalysis(!showSpeakerAnalysis)}
              >
                {showSpeakerAnalysis ? "접기" : "펼치기"}
              </Button>
            </div>
          </div>
          
          {/* Speaker Names Editing */}
          {editingSpeakers && (
            <div className="bg-blue-50 rounded-lg p-4 mb-4 border border-blue-200">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-blue-900">화자 이름 설정</h4>
                <span className="text-xs text-blue-600">저장 후 언제든지 다시 수정 가능</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.keys(speakerNames).map((speaker) => (
                  <div key={speaker} className="bg-white rounded-lg p-3 border border-blue-200">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                        {speaker.replace(/Speaker |화자 /g, '')}
                      </div>
                      <div className="flex-1">
                        <label className="text-xs text-blue-600 font-medium">{speaker}</label>
                        <Input
                          value={speakerNames[speaker]}
                          onChange={(e) => setSpeakerNames(prev => ({
                            ...prev,
                            [speaker]: e.target.value
                          }))}
                          placeholder="이름을 입력하세요 (예: 김철수, A, 발표자)"
                          className="mt-1"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-between items-center mt-4">
                <span className="text-xs text-blue-600">
                  변경사항: {JSON.stringify(speakerNames) !== JSON.stringify(storedSpeakerNames) ? '수정됨' : '변경없음'}
                </span>
                <div className="flex space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      const originalNames: {[key: string]: string} = {};
                      Object.keys(speakerNames).forEach(speaker => {
                        originalNames[speaker] = (storedSpeakerNames as any)[speaker] || speaker.replace('Speaker ', '화자 ');
                      });
                      setSpeakerNames(originalNames);
                    }}
                  >
                    <X className="mr-1 h-3 w-3" />
                    취소
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => updateSpeakerNamesMutation.mutate(speakerNames)}
                    disabled={updateSpeakerNamesMutation.isPending}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Check className="mr-2 h-4 w-4" />
                    {updateSpeakerNamesMutation.isPending ? '저장 중...' : '저장'}
                  </Button>
                </div>
              </div>
            </div>
          )}

          {showSpeakerAnalysis && (
            <div className="space-y-4">
              {Object.entries(speakerSummary).map(([speaker, data]: [string, any]) => {
                const displayName = speakerNames[speaker] || speaker.replace('Speaker ', '화자 ');
                const speakerNum = speaker.replace(/Speaker |화자 /g, '');
                const colors = [
                  'bg-blue-100 text-blue-800 border-blue-200',
                  'bg-green-100 text-green-800 border-green-200',
                  'bg-purple-100 text-purple-800 border-purple-200',
                  'bg-orange-100 text-orange-800 border-orange-200',
                  'bg-pink-100 text-pink-800 border-pink-200',
                  'bg-indigo-100 text-indigo-800 border-indigo-200',
                  'bg-yellow-100 text-yellow-800 border-yellow-200',
                  'bg-red-100 text-red-800 border-red-200'
                ];
                const colorIndex = speakerNum.charCodeAt(0) % colors.length;
                const colorClass = colors[colorIndex] || 'bg-gray-100 text-gray-800 border-gray-200';

                return (
                  <div key={speaker} className="border rounded-lg p-4 border-slate-200">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${colorClass}`}>
                          <span className="font-bold">{speakerNum}</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900 text-lg">{displayName}</h4>
                          <div className="flex items-center space-x-4 text-sm text-slate-600">
                            <span className="flex items-center">
                              <Clock className="w-4 h-4 mr-1" />
                              {typeof data.timeSpent === 'number' 
                                ? `${Math.floor(data.timeSpent / 60)}분 ${data.timeSpent % 60}초`
                                : data.timeSpent || '시간 정보 없음'
                              }
                            </span>
                            <span>{data.totalUtterances}회 발언</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-slate-50 rounded-lg p-3">
                      <h5 className="font-medium text-slate-700 mb-2">주요 키워드:</h5>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {data.keywords && data.keywords.map((keyword: string, index: number) => (
                          <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                            {keyword}
                          </span>
                        ))}
                      </div>
                      {data.summary && (
                        <div>
                          <h5 className="font-medium text-slate-700 mb-2">주요 발언:</h5>
                          <p className="text-sm text-slate-600">{data.summary}</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Summary Section */}
      {recording.summary && (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900 flex items-center">
              <FileText className="text-slate-500 mr-2" />
              요약
            </h3>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setEditingSummary(!editingSummary)}
            >
              <Edit2 className="mr-2 h-4 w-4" />
              {editingSummary ? "완료" : "편집"}
            </Button>
          </div>
          
          {editingSummary ? (
            <div className="space-y-4">
              <Textarea
                value={newSummary}
                onChange={(e) => setNewSummary(e.target.value)}
                placeholder="요약 내용을 입력하세요..."
                rows={6}
                className="w-full"
              />
              <div className="flex justify-end space-x-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setNewSummary(recording.summary || "");
                    setEditingSummary(false);
                  }}
                >
                  <X className="mr-1 h-3 w-3" />
                  취소
                </Button>
                <Button
                  size="sm"
                  onClick={() => updateContentMutation.mutate({ summary: newSummary })}
                  disabled={updateContentMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Check className="mr-2 h-4 w-4" />
                  {updateContentMutation.isPending ? '저장 중...' : '저장'}
                </Button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 rounded-lg p-4">
              <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{recording.summary}</p>
            </div>
          )}
        </div>
      )}

      {/* Transcription Section */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-slate-900 flex items-center">
            <FileText className="text-slate-500 mr-2" />
            전사 결과
          </h3>
          {!speakers || speakers.length === 0 ? (
            <Button
              size="sm"
              variant="outline"
              onClick={() => setEditingTranscription(!editingTranscription)}
            >
              <Edit2 className="mr-2 h-4 w-4" />
              {editingTranscription ? "완료" : "편집"}
            </Button>
          ) : null}
        </div>
        
        {/* Download Actions */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={downloadTranscription}
              disabled={!recording.transcription}
            >
              <Download className="mr-2 h-4 w-4" />
              전사본 다운로드
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={exportSummary}
              disabled={!recording.summary}
            >
              <FileDown className="mr-2 h-4 w-4" />
              요약 다운로드
            </Button>
          </div>
          <Button onClick={onNewRecording} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="mr-2 h-4 w-4" />
            새 녹음
          </Button>
        </div>

        {speakers && speakers.length > 0 ? (
          <div className="space-y-4">
            {/* Search and Filter */}
            <div className="bg-white rounded-lg p-4 border border-slate-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <Input
                    placeholder="전사 내용 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={selectedSpeaker === null ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedSpeaker(null)}
                  >
                    전체
                  </Button>
                  {(() => {
                    const speakerSet = new Set(speakers.map((s: any) => s.speaker));
                    const uniqueSpeakers = Array.from(speakerSet) as string[];
                    return uniqueSpeakers.map((speaker: string) => (
                      <Button
                        key={speaker}
                        variant={selectedSpeaker === speaker ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedSpeaker(speaker)}
                      >
                        {speakerNames[speaker] || speaker.replace('Speaker ', '화자 ')}
                      </Button>
                    ));
                  })()}
                </div>
              </div>
            </div>

            {/* Filtered Utterances */}
            {(() => {
              const filteredUtterances = speakers.filter((utterance: any) => {
                if (selectedSpeaker && utterance.speaker !== selectedSpeaker) {
                  return false;
                }
                if (searchTerm && !utterance.text.toLowerCase().includes(searchTerm.toLowerCase())) {
                  return false;
                }
                return true;
              });

              const totalPages = Math.ceil(filteredUtterances.length / itemsPerPage);
              const startIndex = (currentPage - 1) * itemsPerPage;
              const endIndex = startIndex + itemsPerPage;
              const currentUtterances = filteredUtterances.slice(startIndex, endIndex);

              return (
                <div className="space-y-4">
                  {/* Results Summary */}
                  <div className="flex justify-between items-center text-sm text-slate-600 bg-slate-50 p-3 rounded border">
                    <span>
                      총 {filteredUtterances.length}개 발언 중 {startIndex + 1}-{Math.min(endIndex, filteredUtterances.length)}번째 표시
                    </span>
                    {totalPages > 1 && (
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                          disabled={currentPage === 1}
                        >
                          이전
                        </Button>
                        <span className="text-xs">
                          {currentPage} / {totalPages}
                        </span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                          disabled={currentPage === totalPages}
                        >
                          다음
                        </Button>
                      </div>
                    )}
                  </div>

                  {/* Utterances List */}
                  <div className="space-y-3 max-h-[600px] overflow-y-auto">
                    {currentUtterances.map((utterance: any, index: number) => {
                      const speakerNum = utterance.speaker.replace(/Speaker |화자 /g, '');
                      const colors = [
                        'bg-blue-50 border-blue-200 text-blue-900',
                        'bg-green-50 border-green-200 text-green-900',
                        'bg-purple-50 border-purple-200 text-purple-900',
                        'bg-orange-50 border-orange-200 text-orange-900',
                        'bg-pink-50 border-pink-200 text-pink-900',
                        'bg-indigo-50 border-indigo-200 text-indigo-900',
                        'bg-yellow-50 border-yellow-200 text-yellow-900',
                        'bg-red-50 border-red-200 text-red-900'
                      ];
                      const colorIndex = speakerNum.charCodeAt(0) % colors.length;
                      const colorClass = colors[colorIndex] || 'bg-gray-50 border-gray-200 text-gray-900';

                      const startTime = Math.floor(utterance.start / 1000);
                      const mins = Math.floor(startTime / 60);
                      const secs = startTime % 60;
                      const timeStr = `${mins}:${secs.toString().padStart(2, '0')}`;
                      const displayName = speakerNames[utterance.speaker] || utterance.speaker.replace('Speaker ', '화자 ');

                      return (
                        <div key={index} className={`border rounded-lg p-4 ${colorClass}`}>
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center border-2 border-current">
                                <span className="text-xs font-bold">{speakerNum}</span>
                              </div>
                              <div>
                                <span className="font-semibold">{displayName}</span>
                                <span className="text-xs text-slate-500 ml-2">{timeStr}</span>
                              </div>
                            </div>
                          </div>
                          <p className="text-slate-800 leading-relaxed">{utterance.text}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })()}
          </div>
        ) : (
          <div className="space-y-4">
            {editingTranscription ? (
              <div className="space-y-4">
                <Textarea
                  value={newTranscription}
                  onChange={(e) => setNewTranscription(e.target.value)}
                  placeholder="전사 내용을 입력하세요..."
                  rows={12}
                  className="w-full"
                />
                <div className="flex justify-end space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setNewTranscription(recording.transcription || "");
                      setEditingTranscription(false);
                    }}
                  >
                    <X className="mr-1 h-3 w-3" />
                    취소
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => updateContentMutation.mutate({ transcription: newTranscription })}
                    disabled={updateContentMutation.isPending}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Check className="mr-2 h-4 w-4" />
                    {updateContentMutation.isPending ? '저장 중...' : '저장'}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{recording.transcription || "전사 내용이 없습니다."}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}