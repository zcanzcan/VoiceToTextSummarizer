import { useState, useRef, useCallback, useEffect } from "react";

interface UseAudioRecorderProps {
  onRecordingComplete: (audioBlob: Blob, type: "lecture" | "meeting") => void;
}

export function useAudioRecorder({ onRecordingComplete }: UseAudioRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [isBackgroundMode, setIsBackgroundMode] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const recordingTypeRef = useRef<"lecture" | "meeting" | null>(null);
  const wakeLockRef = useRef<any>(null);

  const startTimer = useCallback(() => {
    timerRef.current = setInterval(() => {
      setRecordingTime(prev => prev + 1);
    }, 1000);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const requestWakeLock = useCallback(async () => {
    try {
      if ('wakeLock' in navigator) {
        wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
        
        wakeLockRef.current.addEventListener('release', () => {
          console.log('Wake lock released');
        });
      }
    } catch (err) {
      console.log('Wake lock not supported or failed:', err);
    }
  }, []);

  const releaseWakeLock = useCallback(async () => {
    if (wakeLockRef.current) {
      try {
        await wakeLockRef.current.release();
        wakeLockRef.current = null;
      } catch (err) {
        console.log('Failed to release wake lock:', err);
      }
    }
  }, []);

  const startRecording = useCallback(async (type: "lecture" | "meeting") => {
    try {
      // Request wake lock to prevent screen from sleeping
      await requestWakeLock();

      // Mobile-optimized audio constraints
      const audioConstraints = {
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          // Mobile-specific optimizations
          sampleRate: { ideal: 48000 },
          channelCount: { ideal: 1 }, // Mono for better mobile performance
          sampleSize: { ideal: 16 }
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(audioConstraints);

      streamRef.current = stream;
      recordingTypeRef.current = type;
      audioChunksRef.current = [];

      // Choose optimal MIME type for mobile devices
      const supportedTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/mp4',
        'audio/wav'
      ];
      
      let mimeType = 'audio/wav'; // fallback
      for (const type of supportedTypes) {
        if (MediaRecorder.isTypeSupported(type)) {
          mimeType = type;
          break;
        }
      }

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType,
        audioBitsPerSecond: 128000 // Optimize for mobile bandwidth
      });

      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { 
          type: mediaRecorder.mimeType 
        });
        
        if (recordingTypeRef.current) {
          onRecordingComplete(audioBlob, recordingTypeRef.current);
        }

        // Cleanup
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
          streamRef.current = null;
        }
        
        await releaseWakeLock();
      };

      // Configure MediaRecorder for persistent background recording
      mediaRecorder.addEventListener('pause', () => {
        console.log('MediaRecorder paused - this should not happen in background mode');
      });
      
      mediaRecorder.addEventListener('resume', () => {
        console.log('MediaRecorder resumed');
      });

      // Start recording with smaller chunks for mobile stability
      mediaRecorder.start(1000); // 1 second chunks for stable background recording
      setIsRecording(true);
      setIsPaused(false);
      setRecordingTime(0);
      startTimer();
      
      console.log('Recording started with background support');
      
    } catch (error) {
      console.error("Error starting recording:", error);
      await releaseWakeLock();
      throw new Error("마이크 접근 권한이 필요합니다.");
    }
  }, [onRecordingComplete, startTimer, requestWakeLock, releaseWakeLock]);

  const stopRecording = useCallback(async () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
      setIsBackgroundMode(false);
      stopTimer();
    }
  }, [isRecording, stopTimer]);

  const pauseRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording && !isPaused) {
      mediaRecorderRef.current.pause();
      setIsPaused(true);
      stopTimer();
    }
  }, [isRecording, isPaused, stopTimer]);

  const resumeRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording && isPaused) {
      mediaRecorderRef.current.resume();
      setIsPaused(false);
      startTimer();
    }
  }, [isRecording, isPaused, startTimer]);

  // Handle page visibility changes for mobile background support
  useEffect(() => {
    let audioContextRef: AudioContext | null = null;
    let sourceRef: MediaStreamAudioSourceNode | null = null;
    
    const handleVisibilityChange = () => {
      if (isRecording) {
        if (document.hidden) {
          setIsBackgroundMode(true);
          
          // Create AudioContext to maintain background audio processing
          if (streamRef.current && !audioContextRef) {
            try {
              audioContextRef = new (window.AudioContext || (window as any).webkitAudioContext)();
              sourceRef = audioContextRef.createMediaStreamSource(streamRef.current);
              
              // Create a gain node to keep the audio context active
              const gainNode = audioContextRef.createGain();
              gainNode.gain.value = 0; // Silent but keeps context alive
              sourceRef.connect(gainNode);
              gainNode.connect(audioContextRef.destination);
              
              console.log('Audio context created for background recording');
            } catch (error) {
              console.log('Failed to create audio context:', error);
            }
          }
        } else {
          setIsBackgroundMode(false);
          
          // Clean up audio context when returning to foreground
          if (audioContextRef) {
            try {
              audioContextRef.close();
              audioContextRef = null;
              sourceRef = null;
              console.log('Audio context cleaned up');
            } catch (error) {
              console.log('Failed to clean up audio context:', error);
            }
          }
          
          // Re-acquire wake lock when returning to foreground
          if (isRecording) {
            requestWakeLock();
          }
        }
      }
    };

    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isRecording) {
        e.preventDefault();
        e.returnValue = '녹음 중입니다. 페이지를 떠나면 녹음이 중단됩니다.';
        return e.returnValue;
      }
    };

    // Prevent automatic pause/stop on mobile focus loss
    const handleFocus = () => {
      if (isRecording && mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
        try {
          mediaRecorderRef.current.resume();
          console.log('Recording resumed on focus');
        } catch (error) {
          console.log('Failed to resume recording:', error);
        }
      }
    };

    const handleBlur = () => {
      // Do NOT pause recording on blur - keep it active in background
      console.log('App lost focus but keeping recording active');
    };

    // Mobile-specific event listeners
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);
    window.addEventListener('focus', handleFocus);
    window.addEventListener('blur', handleBlur);
    
    // iOS Safari specific events
    window.addEventListener('pagehide', handleVisibilityChange);
    window.addEventListener('pageshow', handleVisibilityChange);

    return () => {
      // Cleanup audio context
      if (audioContextRef) {
        try {
          audioContextRef.close();
        } catch (error) {
          console.log('Failed to cleanup audio context on unmount:', error);
        }
      }
      
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('blur', handleBlur);
      window.removeEventListener('pagehide', handleVisibilityChange);
      window.removeEventListener('pageshow', handleVisibilityChange);
    };
  }, [isRecording, requestWakeLock]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopTimer();
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      releaseWakeLock();
    };
  }, [stopTimer, releaseWakeLock]);

  return {
    isRecording,
    isPaused,
    recordingTime,
    isBackgroundMode,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
  };
}
